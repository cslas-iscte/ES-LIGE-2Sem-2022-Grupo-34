/**
 * Vertex and/or edge scoring algorithms.
 */
package org.jgrapht.alg.scoring;
