/**
 * Algorithms for link prediction
 */
package org.jgrapht.alg.linkprediction;
