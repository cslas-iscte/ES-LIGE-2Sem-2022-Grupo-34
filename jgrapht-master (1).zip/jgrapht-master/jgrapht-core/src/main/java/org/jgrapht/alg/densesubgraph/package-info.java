/**
 * Algorithms for computing maximum density subgraphs.
 */
package org.jgrapht.alg.densesubgraph;
